=== LiteSpeed Cache Addon ===

Contributors: Martin C-Scott
Requires at least: 4.0
Requires PHP: 5.6
Tested up to: 5.6
Stable tag: 1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html

== Requirements ==

This plugin is an addon plugin to LiteSpeed Cache


== Changelog ==
=1.0 - Dec 10 2020 =
* Initial release.